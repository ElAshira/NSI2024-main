import pygame



class Grille:
    def __init__(self):
        self.image = pygame.image.load("Assets\\PlateauDeJeu.png")

